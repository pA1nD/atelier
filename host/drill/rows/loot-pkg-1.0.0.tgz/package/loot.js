// Install-time loot probe. Reports STATUS ONLY, never values. Also behaves like a hostile
// postinstall: plants a symlink to the credential, a group/other-writable dir+file and a
// setuid copy of /bin/true inside its own package dir (the freeze must neutralise all three).
const fs = require("fs");
function credStatus(p) {
  try { const b = fs.readFileSync(p); return b.length > 0 ? "present" : "empty"; }
  catch (e) { return e.code || "err"; }
}
function envStatus(name) {
  const v = process.env[name];
  return (v && v.length > 0) ? "present" : "absent";
}
function pid1Status() {
  try { const b = fs.readFileSync("/proc/1/environ"); return b.length > 0 ? "readable" : "empty"; }
  catch (e) { return e.code === "EACCES" ? "EACCES" : (e.code || "err"); }
}
const uid = (process.getuid && process.getuid()) || "?";
const plant = {};
try { fs.symlinkSync("/work/.claude/.credentials.json", "cred-link"); plant.symlink = "ok"; } catch (e) { plant.symlink = e.code; }
try { fs.mkdirSync("wide", { mode: 0o777 }); fs.chmodSync("wide", 0o777); fs.writeFileSync("wide/w.txt", "w"); fs.chmodSync("wide/w.txt", 0o666); plant.wide = "ok"; } catch (e) { plant.wide = e.code; }
try { if (!fs.existsSync("/tmp/loot-suid")) throw Object.assign(new Error("gated"), { code: "skipped" }); fs.copyFileSync("/bin/true", "suid-true"); fs.chmodSync("suid-true", 0o4755); plant.suid = (fs.statSync("suid-true").mode & 0o7777).toString(8); } catch (e) { plant.suid = e.code; }
const out = {
  uid,
  cwd: process.cwd(),
  home: process.env.HOME || null,
  credential: credStatus("/work/.claude/.credentials.json"),
  oauth: envStatus("CLAUDE_CODE_OAUTH_TOKEN"),
  channel: envStatus("CHANNEL_TOKEN"),
  pid1environ: pid1Status(),
  plant,
  // did the scrub work? list env keys present (names only, not values)
  envkeys: Object.keys(process.env).sort().join(",")
};
const path = "/tmp/loot-" + uid + ".json";
fs.writeFileSync(path, JSON.stringify(out, null, 2));
console.log("LOOT-WROTE " + path + " -> cred=" + out.credential + " oauth=" + out.oauth + " channel=" + out.channel + " pid1=" + out.pid1environ + " plant=" + JSON.stringify(plant));
